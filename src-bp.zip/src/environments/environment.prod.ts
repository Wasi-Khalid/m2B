export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyDmwh_ariwC1hZENVvCHVELmFsaMJjO1Z0",
    authDomain: "m2bwholesale-219d4.firebaseapp.com",
    databaseURL: "https://m2bwholesale-219d4.firebaseio.com",
    projectId: "m2bwholesale-219d4",
    storageBucket: "m2bwholesale-219d4.appspot.com",
    messagingSenderId: "545202805485"
  },
  functionsURL: 'https://us-central1-m2bwholesale-219d4.cloudfunctions.net',
  paypalSandboxKey: 'AfNCGm3J5IHxH8_XI2h_zqOAt7sIJw1t54FiCLOq8APE-VoEfSbBhApx1QKbPvJq5QDloJ4JuWeUyQt9',
  paypalProductionKey:'AYUF1sisd8CX6n9wDzO13KAL2wpq9FXZcbcnoZc49cvy2GIW7-zEtlOSKMCZg0B9kRzWMYdOBKHN17Ht',
  appUrl: 'https://m2bapp.herokuapp.com'
};
