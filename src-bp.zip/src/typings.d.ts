/* SystemJS module definition */
declare var module: NodeModule;
interface NodeModule {
  id: string;
}
// declare var StripeCheckout:any;
// declare var Stripe: any;
// declare var elements: any;
declare var Accept: any;
