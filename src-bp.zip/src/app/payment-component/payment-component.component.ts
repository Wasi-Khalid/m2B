import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payment-component',
  templateUrl: './payment-component.component.html',
  styleUrls: ['./payment-component.component.css']
})
export class PaymentComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
