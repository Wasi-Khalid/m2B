export class SettingModel {
  key: string;
  deduction: number;


  constructor() {
    this.deduction = 0;

  }
}

