import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mym2b',
  templateUrl: './mym2b.component.html',
  styleUrls: ['./mym2b.component.css']
})
export class Mym2bComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
