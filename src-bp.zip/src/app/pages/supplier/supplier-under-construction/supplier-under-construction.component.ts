import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-supplier-under-construction',
  templateUrl: './supplier-under-construction.component.html',
  styleUrls: ['./supplier-under-construction.component.css']
})
export class SupplierUnderConstructionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
