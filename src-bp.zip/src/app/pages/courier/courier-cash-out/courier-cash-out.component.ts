import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-courier-cash-out',
  templateUrl: './courier-cash-out.component.html',
  styleUrls: ['./courier-cash-out.component.css']
})
export class CourierCashOutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
